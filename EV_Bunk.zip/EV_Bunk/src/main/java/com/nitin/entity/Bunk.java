package com.nitin.entity;

public class Bunk {
	private int Id;
	private String Bunk_name;
	private String Bunk_address;
	private String Nearby_area;
	private String State;
	private String City;
	private int No_ofSlots;
	private String User_name;
	private String Password;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = id;
	}
	public String getBunk_name() {
		return Bunk_name;
	}
	public void setBunk_name(String bunk_name) {
		this.Bunk_name = bunk_name;
	}
	public String getBunk_address() {
		return Bunk_address;
	}
	public void setBunk_address(String bunk_address) {
		this.Bunk_address = bunk_address;
	}
	public String getNearby_area() {
		return Nearby_area;
	}
	public void setNearby_area(String nearby_area) {
		this.Nearby_area = nearby_area;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		this.State = state;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		this.City = city;
	}
	public int getNo_ofSlots() {
		return No_ofSlots;
	}
	public void setNo_ofSlots(int no_ofSlots) {
		this.No_ofSlots = no_ofSlots;
	}
	public String getUser_name() {
		return User_name;
	}
	public void setUser_name(String user_name) {
		this.User_name = user_name;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		this.Password = password;
	}
	
	
	
}
